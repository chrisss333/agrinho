function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let cityStart = 300;
let bgColor;
let sunX = 50;

function setup() {
  createCanvas(600, 400);
  frameRate(30);
}

function draw() {
  // Fundo mudando gradualmente do campo para a cidade
  bgColor = lerpColor(color(135, 206, 235), color(100), map(mouseX, 0, width, 0, 1));
  background(bgColor);

  // Sol se movendo
  fill(255, 204, 0);
  ellipse(sunX, 80, 50);
  sunX += 0.5;
  if (sunX > width + 25) sunX = -25;

  // Parte rural
  drawField();

  // Parte urbana
  drawCity();

  // Linha de transição
  stroke(255);
  line(cityStart, 0, cityStart, height);
}

function drawField() {
  noStroke();
  fill(34, 139, 34);
  rect(0, height / 2, cityStart, height / 2);

  // Casa rural
  fill(139, 69, 19);
  rect(80, 200, 80, 60);
  fill(255, 0, 0);
  triangle(80, 200, 120, 160, 160, 200);
  
  // Árvore
  fill(139, 69, 19);
  rect(200, 220, 10, 40);
  fill(34, 139, 34);
  ellipse(205, 210, 40, 40);
}

function drawCity() {
  noStroke();
  fill(169, 169, 169);
  rect(cityStart, height / 2, width - cityStart, height / 2);

  // Prédios
  fill(70);
  rect(350, 180, 50, 120);
  rect(420, 150, 60, 150);
  rect(500, 200, 40, 100);

  // Janelas
  fill(255);
  for (let x = 360; x < 390; x += 15) {
    for (let y = 190; y < 290; y += 20) {
      rect(x, y, 8, 10);
    }
  }
}